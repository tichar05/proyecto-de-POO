package clasesInventario;

public class Bodega {
	public String bodega;
	public String capacidad;
	public String descripcion;
	public Bodega(String bodega, String capacidad, String descripcion) {
		super();
		this.bodega = bodega;
		this.capacidad = capacidad;
		this.descripcion = descripcion;
	}

	public Bodega(){

	}

	public String getBodega() {
		return bodega;
	}
	public void setBodega(String bodega) {
		this.bodega = bodega;
	}
	public String getCapacidad() {
		return capacidad;
	}
	public void setCapacidad(String capacidad) {
		this.capacidad = capacidad;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	@Override
	public String toString() {
		return "Bodega [bodega=" + bodega + ", capacidad=" + capacidad + ", descripcion=" + descripcion + "]";
	}


}
