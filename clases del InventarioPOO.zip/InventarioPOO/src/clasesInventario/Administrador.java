package clasesInventario;

public class Administrador {
	public String Administrador;
	public String ID;
	public Administrador(String administrador, String iD) {
		super();
		Administrador = administrador;
		ID = iD;
	}

	public Administrador(){

	}

	public String getAdministrador() {
		return Administrador;
	}

	public void setAdministrador(String administrador) {
		Administrador = administrador;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	@Override
	public String toString() {
		return "Administrador [Administrador=" + Administrador + ", ID=" + ID + "]";
	}


}
