package clasesInventario;

public class Producto {
	public String producto;
	public int precio;
	public int venta;
	public int cantidad;
	protected int cajas;
	protected String descripcion;
	protected String fechaIngreso;
	protected String fechaSalida;
	protected String fechaVencimiento;



	public Producto(String producto, int precio, int venta, int cantidad, int cajas, String descripcion, String fechaIngreso,
			String fechaSalida, String fechaVencimiento) {
		super();
		this.producto = producto;
		this.precio = precio;
		this.venta = venta;
		this.cantidad = cantidad;
		this.cajas = cajas;
		this.descripcion = descripcion;
		this.fechaIngreso = fechaIngreso;
		this.fechaSalida = fechaSalida;
		this.fechaVencimiento = fechaVencimiento;
	}

	public Producto(){

	}

	public String getProducto() {
		return producto;
	}
	public void setProducto(String producto) {
		this.producto = producto;
	}
	public int getPrecio() {
		return precio;
	}
	public void setPrecio(int precio) {
		this.precio = precio;
	}
	public int getVenta() {
		return venta;
	}
	public void setVenta(int venta) {
		this.venta = venta;
	}
	public int getCantidad() {
		return cantidad;
	}
	public void setCantidad(int cantidad){
		this.cantidad = cantidad;
	}
	public int getCajas() {
		return cajas;
	}
	public void setCajas(int cajas) {
		this.cajas = cajas;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getFechaIngreso() {
		return fechaIngreso;
	}
	public void setFechaIngreso(String fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}
	public String getFechaSalida() {
		return fechaSalida;
	}
	public void setFechaSalida(String fechaSalida) {
		this.fechaSalida = fechaSalida;
	}
	public String getFechaVencimiento() {
		return fechaVencimiento;
	}
	public void setFechaVencimiento(String fechaVencimiento) {
		this.fechaVencimiento = fechaVencimiento;
	}
	@Override
	public String toString() {
		return "Producto [producto=" + producto + ", precio=" + precio + ", venta=" + venta + ", cajas=" + cajas
				+ ", descripcion=" + descripcion + ", fechaIngreso=" + fechaIngreso + ", fechaSalida=" + fechaSalida
				+ ", fechaVencimiento=" + fechaVencimiento + "]";
	}


}
