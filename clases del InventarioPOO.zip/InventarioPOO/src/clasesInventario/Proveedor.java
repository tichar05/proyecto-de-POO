package clasesInventario;

public class Proveedor {
	public String proveedor;
	public String descripcion;
	public Proveedor(String proveedor, String descripcion) {
		super();
		this.proveedor = proveedor;
		this.descripcion = descripcion;
	}

	public Proveedor(){

	}

	public String getProveedor() {
		return proveedor;
	}
	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	@Override
	public String toString() {
		return "Proveedor [proveedor=" + proveedor + ", descripcion=" + descripcion + "]";
	}


	}


