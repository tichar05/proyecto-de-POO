package principalInventario;



import java.util.ArrayList;

import javax.swing.JFrame;

import clasesInventario.Producto;
import clasesInventario.Bodega;
import clasesInventario.Proveedor;
import clasesInventario.Administrador;

public class Inventario{
	public JFrame ventana;





	public ArrayList<Producto> producto;
	public ArrayList<Bodega> bodega;
	public ArrayList<Proveedor> proveedor;
	public ArrayList<Administrador> administrador;

	public Inventario(){
		inicializarVentana();
		ventana.setVisible(true);
	}

	public void inicializarVentana(){
		ventana=new JFrame("Inventario");
		ventana.setSize(692, 545);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.setLayout(null);
		ventana.setLocationRelativeTo(null);
	}

	public static void main(String[] args) {
		new Inventario();

	}

}
